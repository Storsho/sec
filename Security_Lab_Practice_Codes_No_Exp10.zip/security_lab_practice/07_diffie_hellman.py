# EXPERIMENT 6: DIFFIE–HELLMAN KEY EXCHANGE
# Problem statement: Read public values p and g and private values for Alice and Bob,
# calculate their public keys and independently calculate/compare their shared secret.
# Small values are for demonstration only, not production cryptography.
def main():
    try:
        p=int(input('Enter prime number (p): ')); g=int(input('Enter primitive root (g): '))
        a=int(input("Enter Alice's private key: ")); b=int(input("Enter Bob's private key: "))
    except ValueError: print('All values must be integers.'); return
    if p<=2 or not (1<g<p) or a<=0 or b<=0:
        print('Use p > 2, 1 < g < p, and positive private keys.'); return
    A=pow(g,a,p); B=pow(g,b,p)
    alice_shared=pow(B,a,p); bob_shared=pow(A,b,p)
    print('\n--- Diffie-Hellman Key Exchange ---')
    print('Prime Number (p):',p); print('Base (g):',g)
    print("Alice's Private Key:",a); print("Bob's Private Key:",b)
    print("Alice's Public Key:",A); print("Bob's Public Key:",B)
    print("Shared Secret computed by Alice:",alice_shared)
    print("Shared Secret computed by Bob:",bob_shared)
    print('Verification:', 'Both shared secrets are identical.' if alice_shared==bob_shared else 'Mismatch.')
if __name__=='__main__': main()
