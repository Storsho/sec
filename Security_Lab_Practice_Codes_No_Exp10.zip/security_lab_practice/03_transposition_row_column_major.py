# EXPERIMENT 2: TRANSPOSITION TECHNIQUES — ROW MAJOR AND COLUMN MAJOR
# Problem statement: Implement row-major transformation (fill column-wise, read row-wise)
# and column-major transformation (fill row-wise, read column-wise), with X padding,
# display matrices, and decrypt each ciphertext back to the plaintext.
import math

def make_matrix(text, cols, fill_by_columns):
    if cols <= 0: raise ValueError('Number of columns must be positive.')
    rows=math.ceil(len(text)/cols)
    padded=text+'X'*(rows*cols-len(text))
    m=[['']*cols for _ in range(rows)]
    k=0
    if fill_by_columns:
        for c in range(cols):
            for r in range(rows): m[r][c]=padded[k]; k+=1
    else:
        for r in range(rows):
            for c in range(cols): m[r][c]=padded[k]; k+=1
    return m

def show(m):
    for row in m: print(' '.join(row))
def row_major_encrypt(text,cols):
    m=make_matrix(text,cols,True); print('\nEncryption Matrix (Row Major):'); show(m)
    return ''.join(ch for row in m for ch in row)
def row_major_decrypt(cipher,cols):
    rows=len(cipher)//cols; m=[['']*cols for _ in range(rows)]; k=0
    for r in range(rows):
        for c in range(cols): m[r][c]=cipher[k]; k+=1
    plain=''.join(m[r][c] for c in range(cols) for r in range(rows))
    return plain.rstrip('X')
def column_major_encrypt(text,cols):
    m=make_matrix(text,cols,False); print('\nEncryption Matrix (Column Major):'); show(m)
    return ''.join(m[r][c] for c in range(cols) for r in range(len(m)))
def column_major_decrypt(cipher,cols):
    rows=len(cipher)//cols; m=[['']*cols for _ in range(rows)]; k=0
    for c in range(cols):
        for r in range(rows): m[r][c]=cipher[k]; k+=1
    return ''.join(ch for row in m for ch in row).rstrip('X')
def main():
    text=''.join(input('Enter plaintext: ').split()).upper()
    if not text: print('Plaintext cannot be empty.'); return
    try: cols=int(input('Enter number of columns: '))
    except ValueError: print('Columns must be an integer.'); return
    if cols<=0: print('Columns must be positive.'); return
    c1=row_major_encrypt(text,cols); print('\nRow Major Ciphertext:',c1); print('Row Major Decrypted Plaintext:',row_major_decrypt(c1,cols))
    c2=column_major_encrypt(text,cols); print('\nColumn Major Ciphertext:',c2); print('Column Major Decrypted Plaintext:',column_major_decrypt(c2,cols))
if __name__=='__main__': main()
