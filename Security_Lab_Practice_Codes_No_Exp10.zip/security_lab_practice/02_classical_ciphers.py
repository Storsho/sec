# EXPERIMENT 1(b): CAESAR, PLAYFAIR AND HILL CIPHERS
# Problem statement: Implement (1) Caesar encryption/decryption with key 3,
# (2) Playfair cipher using a 5x5 keyword matrix with I/J combined, and
# (3) a 2x2 Hill cipher using modular arithmetic and an invertible key matrix.
import math
from math import gcd

def caesar(text, key):
    out=[]
    for ch in text:
        if ch.isalpha() and ch.isascii():
            base=ord('A') if ch.isupper() else ord('a')
            out.append(chr((ord(ch)-base+key)%26+base))
        else: out.append(ch)
    return ''.join(out)

def playfair_matrix(keyword):
    keyword=keyword.upper().replace('J','I')
    letters=[]
    for ch in keyword+'ABCDEFGHIKLMNOPQRSTUVWXYZ':
        if 'A' <= ch <= 'Z' and ch != 'J' and ch not in letters: letters.append(ch)
    return [letters[i:i+5] for i in range(0,25,5)]

def pf_pos(matrix, ch):
    if ch=='J': ch='I'
    for r,row in enumerate(matrix):
        if ch in row: return r,row.index(ch)
    raise ValueError(f'Unsupported character: {ch}')

def playfair_prepare(text):
    text=''.join(ch for ch in text.upper().replace('J','I') if 'A' <= ch <= 'Z')
    out=[]; i=0
    while i < len(text):
        a=text[i]
        if i+1>=len(text): out.extend([a,'X']); i+=1
        elif text[i+1]==a: out.extend([a,'X']); i+=1
        else: out.extend([a,text[i+1]]); i+=2
    return ''.join(out)

def playfair_transform(matrix, text, decrypt=False):
    text = ''.join(ch for ch in text.upper().replace('J','I') if 'A' <= ch <= 'Z') if decrypt else playfair_prepare(text)
    if len(text)%2: text += 'X'
    out=[]; step=-1 if decrypt else 1
    for i in range(0,len(text),2):
        a,b=text[i:i+2]; r1,c1=pf_pos(matrix,a); r2,c2=pf_pos(matrix,b)
        if r1==r2: out.extend([matrix[r1][(c1+step)%5],matrix[r2][(c2+step)%5]])
        elif c1==c2: out.extend([matrix[(r1+step)%5][c1],matrix[(r2+step)%5][c2]])
        else: out.extend([matrix[r1][c2],matrix[r2][c1]])
    return ''.join(out)

def mod_inverse(a,m=26):
    for x in range(1,m):
        if (a*x)%m==1: return x
    return None

def hill_inverse(K):
    a,b=K[0]; c,d=K[1]; det=(a*d-b*c)%26; invdet=mod_inverse(det)
    if invdet is None: return None
    return [[d*invdet%26,(-b)*invdet%26],[(-c)*invdet%26,a*invdet%26]]

def clean_hill(text): return ''.join(ch for ch in text.upper() if 'A'<=ch<='Z')
def hill_transform(K,text):
    text=clean_hill(text)
    if len(text)%2: text+='X'
    out=[]
    for i in range(0,len(text),2):
        x,y=ord(text[i])-65,ord(text[i+1])-65
        out.extend([ (K[0][0]*x+K[0][1]*y)%26, (K[1][0]*x+K[1][1]*y)%26 ])
    return ''.join(chr(x+65) for x in out)

def main():
    print('CAESAR CIPHER (fixed key = 3)')
    plain=input('Enter string: '); cipher=caesar(plain,3)
    print('Encrypted:',cipher); print('Decrypted:',caesar(cipher,-3))
    print('\nPLAYFAIR CIPHER')
    key=input('Enter keyword [Monarchy]: ').strip() or 'Monarchy'; matrix=playfair_matrix(key)
    print('Key matrix:')
    for row in matrix: print(' '.join(row))
    plain=input('Enter plaintext: '); cipher=playfair_transform(matrix,plain)
    print('Prepared plaintext:',playfair_prepare(plain)); print('Encrypted:',cipher)
    print('Decrypted (digraph form; X may be filler):',playfair_transform(matrix,cipher,True))
    print('\nHILL CIPHER (2x2)')
    try: K=[[int(input('a: ')),int(input('b: '))],[int(input('c: ')),int(input('d: '))]]
    except ValueError: print('Matrix entries must be integers.'); return
    inv=hill_inverse(K)
    if inv is None: print('Invalid key: determinant has no inverse modulo 26.'); return
    plain=input('Enter plaintext: '); cipher=hill_transform(K,plain)
    print('Encrypted:',cipher); print('Decrypted (X may be padding):',hill_transform(inv,cipher))

if __name__=='__main__': main()
