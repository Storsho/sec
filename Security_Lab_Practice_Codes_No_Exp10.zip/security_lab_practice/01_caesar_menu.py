# EXPERIMENT 1(a): CAESAR CIPHER — MENU-DRIVEN IMPLEMENTATION
# Problem statement: Implement Caesar cipher encryption, decryption, brute-force attack,
# and exit options. Preserve letter case and leave non-alphabetic characters unchanged.

def shift_text(text, key):
    result = []
    key %= 26
    for ch in text:
        if 'a' <= ch <= 'z':
            result.append(chr((ord(ch) - ord('a') + key) % 26 + ord('a')))
        elif 'A' <= ch <= 'Z':
            result.append(chr((ord(ch) - ord('A') + key) % 26 + ord('A')))
        else:
            result.append(ch)
    return ''.join(result)

def main():
    while True:
        print("\n--- Caesar Cipher Menu ---\n1. Encrypt\n2. Decrypt\n3. Brute Force Attack\n4. Exit")
        choice = input("Enter your choice: ").strip()
        if choice == '1':
            text = input("Enter plaintext: ")
            try: key = int(input("Enter key: "))
            except ValueError: print("Key must be an integer."); continue
            print("Encrypted Text:", shift_text(text, key))
        elif choice == '2':
            text = input("Enter ciphertext: ")
            try: key = int(input("Enter key: "))
            except ValueError: print("Key must be an integer."); continue
            print("Decrypted Text:", shift_text(text, -key))
        elif choice == '3':
            text = input("Enter ciphertext: ")
            for key in range(26): print(f"Key {key}: {shift_text(text, -key)}")
        elif choice == '4':
            print("Program Ended."); break
        else: print("Invalid choice.")

if __name__ == '__main__': main()
