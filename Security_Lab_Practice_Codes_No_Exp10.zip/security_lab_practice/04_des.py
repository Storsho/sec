# EXPERIMENT 3: DATA ENCRYPTION STANDARD (DES)
# Problem statement: Encrypt a plaintext using DES and an 8-byte key in ECB mode,
# display ciphertext as hexadecimal, decrypt it, remove padding, and verify recovery.
# Educational lab example only: DES and ECB are not secure for real-world use.
from Crypto.Cipher import DES
from Crypto.Util.Padding import pad, unpad

plaintext=input('Enter the plaintext: ')
key_text=input('Enter 8-byte secret key (8 ASCII characters): ')
key=key_text.encode('utf-8')
if len(key)!=8:
    raise SystemExit('Error: key must encode to exactly 8 bytes.')
cipher=DES.new(key,DES.MODE_ECB)
ciphertext=cipher.encrypt(pad(plaintext.encode('utf-8'),DES.block_size))
decrypted=unpad(DES.new(key,DES.MODE_ECB).decrypt(ciphertext),DES.block_size).decode('utf-8')
print('\n----- DES Encryption & Decryption -----')
print('Plaintext           :',plaintext)
print('Secret Key          :',key_text)
print('Ciphertext (Hex)    :',ciphertext.hex())
print('Decrypted Plaintext :',decrypted)
print('Verification        :', 'SUCCESS' if decrypted==plaintext else 'FAILED')
