# EXPERIMENT 9: DIGITAL SIGNATURE SYSTEM — RSA WITH SHA-256
# Problem statement: Menu-driven generation of RSA keys, signing and verifying messages,
# detecting message tampering, and simulating signed e-mail communication.
from pathlib import Path
from Crypto.PublicKey import RSA
from Crypto.Signature import pkcs1_15
from Crypto.Hash import SHA256

PRIVATE_KEY_FILE=Path('private_key.pem')
PUBLIC_KEY_FILE=Path('public_key.pem')
SIGNATURE_FILE=Path('signature.txt')
MESSAGE_FILE=Path('signed_message.txt')

def generate_keys():
    key=RSA.generate(2048)
    PRIVATE_KEY_FILE.write_bytes(key.export_key())
    PUBLIC_KEY_FILE.write_bytes(key.publickey().export_key())
    print('RSA key pair generated and saved.')
    print('Private key saved to:',PRIVATE_KEY_FILE.resolve())
    print('Public key saved to:',PUBLIC_KEY_FILE.resolve())

def load_private_key():
    if not PRIVATE_KEY_FILE.exists(): print('Private key not found. Generate keys first.'); return None
    return RSA.import_key(PRIVATE_KEY_FILE.read_bytes())
def load_public_key():
    if not PUBLIC_KEY_FILE.exists(): print('Public key not found. Generate keys first.'); return None
    return RSA.import_key(PUBLIC_KEY_FILE.read_bytes())
def sign_message():
    key=load_private_key()
    if key is None: return
    message=input('Enter message to sign: '); digest=SHA256.new(message.encode('utf-8'))
    signature=pkcs1_15.new(key).sign(digest)
    SIGNATURE_FILE.write_text(signature.hex(),encoding='utf-8'); MESSAGE_FILE.write_text(message,encoding='utf-8')
    print('Message:',message); print('SHA-256 digest:',digest.hexdigest()); print('Signature (hex):',signature.hex())
    print('Saved signature to signature.txt and message to signed_message.txt.')
def verify_signature():
    key=load_public_key()
    if key is None: return
    message=input('Enter received message: '); sig_hex=input('Enter received signature (hex): ').strip()
    try:
        pkcs1_15.new(key).verify(SHA256.new(message.encode('utf-8')),bytes.fromhex(sig_hex))
        print('Signature Status: VALID')
    except (ValueError,TypeError): print('Signature Status: INVALID (message/signature mismatch)')
def demonstrate_tampering():
    private=load_private_key(); public=load_public_key()
    if private is None or public is None: return
    original=input('Enter original message: '); signature=pkcs1_15.new(private).sign(SHA256.new(original.encode('utf-8')))
    tampered=input('Enter modified/tampered message: ')
    try: pkcs1_15.new(public).verify(SHA256.new(tampered.encode('utf-8')),signature); print('Tampered-message verification: VALID')
    except (ValueError,TypeError): print('Tampered-message verification: INVALID — alteration detected.')
def secure_email_simulation():
    alice=RSA.generate(2048); public=alice.publickey()
    message=input("Alice - enter message: "); signature=pkcs1_15.new(alice).sign(SHA256.new(message.encode('utf-8')))
    print('Message sent to Bob:',message)
    try: pkcs1_15.new(public).verify(SHA256.new(message.encode('utf-8')),signature); print('Bob verifies original: VALID')
    except (ValueError,TypeError): print('Bob verifies original: INVALID')
    altered=input('Modify the received message for tampering test: ')
    try: pkcs1_15.new(public).verify(SHA256.new(altered.encode('utf-8')),signature); print('Bob verifies modified: VALID')
    except (ValueError,TypeError): print('Bob verifies modified: INVALID — tampering detected.')
def main():
    while True:
        print('\n========== DIGITAL SIGNATURE SYSTEM ==========\n1. Generate RSA public/private keys\n2. Digitally sign a message\n3. Verify a digital signature\n4. Demonstrate message tampering\n5. Secure e-mail simulation\n6. Exit')
        choice=input('Enter choice: ').strip()
        if choice=='1': generate_keys()
        elif choice=='2': sign_message()
        elif choice=='3': verify_signature()
        elif choice=='4': demonstrate_tampering()
        elif choice=='5': secure_email_simulation()
        elif choice=='6': print('Program terminated.'); break
        else: print('Invalid choice.')
if __name__=='__main__': main()
