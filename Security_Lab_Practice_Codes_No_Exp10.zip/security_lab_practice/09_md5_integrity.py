# EXPERIMENT 8: MD5 MESSAGE DIGEST AND FILE INTEGRITY MONITORING
# Problem statement: Menu-driven MD5 digest generation, message-integrity verification,
# avalanche-effect demonstration, file checksum generation, and MD5/SHA-1/SHA-256 comparison.
# MD5 and SHA-1 are collision-broken; use SHA-256 or stronger for security-sensitive work.
import hashlib

def md5_hash(text): return hashlib.md5(text.encode('utf-8')).hexdigest()
def generate_md5():
    text=input('Enter text message: '); print('Original Message:',text); print('MD5 Digest:',md5_hash(text))
def verify_integrity():
    text=input('Enter text message: '); given=input('Enter previously generated MD5 digest: ').strip()
    actual=md5_hash(text); print('Calculated MD5:',actual); print('Given MD5:',given)
    print('Result:', 'MATCH' if actual.lower()==given.lower() else 'DOES NOT MATCH')
def avalanche_effect():
    a=input('Enter first message: '); b=input('Enter second message: ')
    print('Message 1:',a,'\nMD5:',md5_hash(a)); print('Message 2:',b,'\nMD5:',md5_hash(b))
    print('A small input change should produce a substantially different digest.')
def file_md5(path):
    h=hashlib.md5()
    with open(path,'rb') as f:
        for block in iter(lambda:f.read(4096),b''): h.update(block)
    return h.hexdigest()
def generate_file_checksum():
    path=input('Enter file path: ')
    try: checksum=file_md5(path)
    except OSError as exc: print('Could not read file:',exc); return
    print('File:',path); print('MD5 Checksum:',checksum)
def compare_hashes():
    text=input('Enter text message: '); data=text.encode('utf-8')
    for name,func in [('MD5',hashlib.md5),('SHA-1',hashlib.sha1),('SHA-256',hashlib.sha256)]:
        digest=func(data).hexdigest(); print(f'{name}: {digest} ({len(digest)} hexadecimal characters)')
def main():
    while True:
        print('\n========== MD5 MENU ==========\n1. Generate MD5 digest\n2. Verify message integrity\n3. Avalanche effect\n4. Generate MD5 file checksum\n5. Compare MD5, SHA-1 and SHA-256\n6. Exit')
        choice=input('Enter choice: ').strip()
        if choice=='1': generate_md5()
        elif choice=='2': verify_integrity()
        elif choice=='3': avalanche_effect()
        elif choice=='4': generate_file_checksum()
        elif choice=='5': compare_hashes()
        elif choice=='6': print('Program terminated.'); break
        else: print('Invalid choice.')
if __name__=='__main__': main()
