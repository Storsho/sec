# EXPERIMENT 7: SHA-1 MESSAGE DIGEST
# Problem statement: Provide a menu to generate a SHA-1 digest, demonstrate the avalanche
# effect, compare two messages, and show SHA-1 padding/length encoding in 512-bit blocks.
# SHA-1 is deprecated for security-sensitive use; this is for the lab demonstration only.
import hashlib

def sha1_hash(message): return hashlib.sha1(message.encode('utf-8')).hexdigest()
def generate_digest():
    message=input('Enter the text message: '); print('Original Message:',message); print('SHA-1 Digest:',sha1_hash(message))
def avalanche_effect():
    message=input('Enter the original message: ')
    if not message: print('Message cannot be empty.'); return
    try: pos=int(input(f'Character position to modify (1-{len(message)}): '))
    except ValueError: print('Position must be an integer.'); return
    if not 1<=pos<=len(message): print('Invalid position.'); return
    new=input('Enter exactly one replacement character: ')
    if len(new)!=1: print('Enter exactly one character.'); return
    changed=message[:pos-1]+new+message[pos:]
    print('Original:',message,'\nSHA-1:',sha1_hash(message)); print('Modified:',changed,'\nSHA-1:',sha1_hash(changed))
def compare_messages():
    a=input('Enter first message: '); b=input('Enter second message: ')
    ha,hb=sha1_hash(a),sha1_hash(b)
    print('Message 1 SHA-1:',ha); print('Message 2 SHA-1:',hb)
    print('Result:', 'Messages are identical based on digest.' if ha==hb else 'Messages are different based on digest.')
def preprocessing():
    message=input('Enter a sentence: '); raw=message.encode('utf-8')
    bits=''.join(format(byte,'08b') for byte in raw); original_length=len(bits)
    padded=bits+'1'; padded+='0'*((448-len(padded)%512)%512); padded+=format(original_length,'064b')
    print('Original message:',message); print('Binary representation:',bits)
    print('Original length:',original_length,'bits'); print('64-bit length:',format(original_length,'064b'))
    print('Total padded length:',len(padded),'bits')
    for i in range(0,len(padded),512): print(f'Block {i//512+1} ({len(padded[i:i+512])} bits):\n{padded[i:i+512]}')
    print('SHA-1 digest:',sha1_hash(message))
def main():
    while True:
        print('\n========== SHA-1 MENU ==========\n1. Generate digest\n2. Avalanche effect\n3. Compare two messages\n4. Preprocessing and 512-bit blocks\n5. Exit')
        choice=input('Enter choice: ').strip()
        if choice=='1': generate_digest()
        elif choice=='2': avalanche_effect()
        elif choice=='3': compare_messages()
        elif choice=='4': preprocessing()
        elif choice=='5': print('Program terminated.'); break
        else: print('Invalid choice.')
if __name__=='__main__': main()
