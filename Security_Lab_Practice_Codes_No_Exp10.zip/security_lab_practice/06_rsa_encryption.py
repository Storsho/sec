# EXPERIMENT 5: RSA ENCRYPTION AND DECRYPTION
# Problem statement: Generate a 2048-bit RSA key pair, encrypt a message with the public
# key using OAEP, decrypt with the private key, and verify that plaintext is recovered.
from Crypto.PublicKey import RSA
from Crypto.Cipher import PKCS1_OAEP

key=RSA.generate(2048)
private_pem=key.export_key(); public_pem=key.publickey().export_key()
print('========== GENERATED PUBLIC KEY ==========\n',public_pem.decode())
print('========== GENERATED PRIVATE KEY =========\n',private_pem.decode())
plaintext=input('Enter plaintext: ')
public_cipher=PKCS1_OAEP.new(RSA.import_key(public_pem))
# OAEP has a size limit; for larger data, encrypt a random AES key instead.
try: ciphertext=public_cipher.encrypt(plaintext.encode('utf-8'))
except ValueError as exc: raise SystemExit(f'RSA message too long for this key/OAEP: {exc}')
print('\nEncrypted Ciphertext (Hex):',ciphertext.hex())
decrypted=PKCS1_OAEP.new(RSA.import_key(private_pem)).decrypt(ciphertext).decode('utf-8')
print('Decrypted Plaintext:',decrypted)
print('Verification:', 'SUCCESS' if decrypted==plaintext else 'FAILED')
