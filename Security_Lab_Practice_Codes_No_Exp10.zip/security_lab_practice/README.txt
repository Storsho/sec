DATA SECURITY LABORATORY — PRACTICE CODE PACK

Based on Security Lab Record (ICS1711). Experiment 10 (Simple Blockchain with Proof of Work) is intentionally excluded as requested.

FILES
01_caesar_menu.py — Experiment 1(a): Caesar menu, encrypt/decrypt/brute force
02_classical_ciphers.py — Experiment 1(b): Caesar, Playfair, Hill
03_transposition_row_column_major.py — Experiment 2: Row-major and column-major transposition (as described in the record)
04_des.py — Experiment 3: DES encrypt/decrypt
05_aes.py — Experiment 4: AES-128 encrypt/decrypt
06_rsa_encryption.py — Experiment 5: RSA-OAEP encrypt/decrypt
07_diffie_hellman.py — Experiment 6: Diffie–Hellman key exchange
08_sha1_message_digest.py — Experiment 7: SHA-1 digest, avalanche effect, comparison, preprocessing
09_md5_integrity.py — Experiment 8: MD5 digest, integrity check, avalanche, file checksum, hash comparison
10_digital_signature_rsa_sha256.py — Experiment 9: RSA/SHA-256 signatures, verification, tampering, e-mail simulation

SETUP
1. Use Python 3.10+ (Python 3.11 is fine).
2. For DES, AES, RSA and digital signatures install PyCryptodome: python -m pip install pycryptodome
3. Run a file from this directory with: python filename.py
4. The other scripts use only Python's standard library.

NOTES / CORRECTIONS
- Every code file begins with its experiment problem statement as comments.
- The code has been cleaned for syntax, input checks, and round-trip checks where relevant.
- Experiment 2 is named “Rail Fence” in the record, but its actual stated algorithm is matrix-based row/column-major transposition; this pack follows that actual problem description.
- Playfair decryption can retain filler X characters because X may be part of the original plaintext; output is shown as digraph form.
- DES, MD5 and SHA-1 are outdated for real security; use them only for this educational lab. ECB mode is used to match the record, not as a recommendation for real applications.
- RSA key generation is random, so keys and ciphertexts differ each run.
